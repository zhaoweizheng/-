//
//  MusicPartnerDownloadEntity.m
//  MusicPartnerDownload
//
//  Created by 度周末网络-王腾 on 16/1/27.
//  Copyright © 2016年 dzmmac. All rights reserved.
//

#import "MusicPartnerDownloadEntity.h"

@implementation MusicPartnerDownloadEntity

@end
