//
//  UITabBarController+MPDownLoad.h
//  MusicPartnerDownload
//
//  Created by 度周末网络-王腾 on 16/1/28.
//  Copyright © 2016年 dzmmac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITabBarController (MPDownLoad) <UITabBarControllerDelegate>


-(void)setUpMPDownLoadStateBade;

@end
